module.exports.function = function openApp (vliveVideoEvent) {
  const console = require('console');

  return vliveVideoEvent.videoUrl;
}
