module.exports.function = function openBrowser (vliveVideoEvent) {
  const console = require('console');

  return vliveVideoEvent.videoUrl;
}
