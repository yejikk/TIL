from django.apps import AppConfig


class NuguappsConfig(AppConfig):
    name = 'nuguapps'
